# MeshSync

**A self-healing mesh network with CRDT-based eventual consistency for disaster-zone and rural sensor deployments.**

Flood gauges and agricultural sensors in remote or disaster-hit areas often have no stable internet and no central broker (MQTT/cloud). MeshSync is a simulation showing how sensor nodes can relay data hop-by-hop through each other and still end up agreeing on the same data, even when parts of the network are cut off for long periods.

## How it works

1. **Mesh routing layer (`routing.py`)** - Flooding with duplicate suppression. Each message has a unique ID and a hop limit (TTL). Every node processes a message once and forwards it to its other active neighbours. If a link or node dies, the next flood simply uses the links that still exist, so there is no route table to repair.
2. **Eventual consistency layer (`crdt.py`, `lamport_clock.py`)** - Conflict-free Replicated Data Types. Every node keeps its own copy of the data and merges whatever it receives. Merge is commutative, associative and idempotent, so all nodes converge to the same state regardless of message order, duplicates or delays. No central authority is needed.
3. **Integration layer (`simulation.py`)** - Drives routing, CRDTs and clocks together. A node with a dead radio still records its own sensor readings locally and delivers them after it reconnects.

### Why flooding instead of full AODV
At 8-10 nodes flooding's overhead is negligible, duplicate delivery is harmless because every payload is a mergeable CRDT state, and self-healing comes for free.

### CRDT type per data category

| Data | CRDT | Reason |
|---|---|---|
| Latest reading per sensor | LWW-Map | Only the current value matters |
| Full history of sensor events | G-Set | Events are never removed; merge is set union |
| Node active/inactive status | LWW-Register | One value that is overwritten over time |
| Relay counters | G-Counter | Only increases; merge is element-wise max |

Ordering uses **Lamport logical clocks** instead of wall-clock time. Ties are broken by node ID so every replica picks the same winner.

## Project structure

```
meshsync_web/
  app.py              Flask API (thin: validates input, calls simulation)
  simulation.py       Integration layer: network + clocks + CRDT stores + routers
  routing.py          Flooding-with-dedup, sync_round(), check_convergence()
  crdt.py             GSet, LWWMap, LWWRegister, GCounter, NodeCRDTStore
  lamport_clock.py    Lamport clock + (timestamp, node_id) ordering
  mesh_engine.py      Nodes, positions, radio range, adjacency, disconnect/reconnect
  test_routing.py     7 tests: routing + CRDT behaviour
  test_simulation.py  9 tests: integration + Flask API
  templates/index.html, static/app.js, static/style.css   Browser page
  requirements.txt
```

## Setup and run

Requires Python 3.9+.

```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000. Click a node to disconnect or reconnect it, and use the side panel to inject a reading.

## Run the tests

```bash
python test_routing.py       # 7 tests, standard library only
python test_simulation.py    # 9 tests, needs Flask
```

Both should end with `ALL ... PASSED`. They cover: multi-hop delivery, dedup, TTL, partition and healing, convergence across 200 random failure/reconnect scenarios, Lamport clock catch-up, CRDT merge properties, and API validation.

## API

| Endpoint | Purpose |
|---|---|
| `GET /api/state` | Topology, per-node CRDT state, convergence status, recent log |
| `GET /api/convergence` | Per-group and full convergence report |
| `GET /api/log` | Event log |
| `POST /api/inject/<id>` | Inject a reading. Body: `{"sensor": "water_level", "value": 4.2}` |
| `POST /api/disconnect/<id>` | Simulate radio failure |
| `POST /api/reconnect/<id>` | Restore the node and sync |
| `POST /api/sync` | Run one anti-entropy round |
| `POST /api/reset` | Reset to the initial state |
| `POST /api/scenario/random` | Random failures + writes + reconnect order, returns convergence. Body (optional): `{"seed": 7}` |
| `GET /api/reachable/<a>/<b>` | Are two nodes currently connected? |

Real sensors (ESP32/Arduino) can feed the system by POSTing to `/api/inject/<id>`.

`converged` means every connected group is internally consistent. `fully_converged` means every node in the network is identical, which is only possible when no node is cut off.

## Status

| Component | Status |
|---|---|
| Node/graph engine, Lamport clock, CRDT layer, flooding routing | Done, tested |
| Flask API integrated with routing + CRDT | Done, tested |
| Frontend: per-node CRDT state, convergence indicator, message paths | To do (page currently shows topology + latest readings) |
| Demo scenario UI and metrics/graphs | To do |
| Real-sensor input (ESP32/Arduino) | To do |
| Final report | To do |

## Team

- Name 1 -
- Name 2 -
- Name 3 -

Final submission: first week of December 2026.
