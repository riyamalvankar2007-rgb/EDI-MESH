const canvas = document.getElementById("meshCanvas");
const ctx = canvas.getContext("2d");

const injectNodeSelect = document.getElementById("injectNode");
const injectValueInput = document.getElementById("injectValue");
const injectBtn = document.getElementById("injectBtn");
const tickCountEl = document.getElementById("tickCount");
const componentsListEl = document.getElementById("componentsList");
const nodeTableBody = document.querySelector("#nodeTable tbody");

let latestState = null;
const NODE_RADIUS = 16;
const PADDING = 40;

// ------------------------------------------------------------------
// Coordinate mapping: simulation (x,y) -> canvas pixels
// ------------------------------------------------------------------
function computeBounds(nodes) {
  const xs = nodes.map((n) => n.x);
  const ys = nodes.map((n) => n.y);
  return {
    minX: Math.min(...xs), maxX: Math.max(...xs),
    minY: Math.min(...ys), maxY: Math.max(...ys),
  };
}

function toCanvasCoords(node, bounds) {
  const { minX, maxX, minY, maxY } = bounds;
  const spanX = maxX - minX || 1;
  const spanY = maxY - minY || 1;
  const usableW = canvas.width - 2 * PADDING;
  const usableH = canvas.height - 2 * PADDING;
  return {
    x: PADDING + ((node.x - minX) / spanX) * usableW,
    y: PADDING + ((node.y - minY) / spanY) * usableH,
  };
}

// ------------------------------------------------------------------
// Rendering
// ------------------------------------------------------------------
function draw(state) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const bounds = computeBounds(state.nodes);
  const posById = {};
  state.nodes.forEach((n) => { posById[n.id] = toCanvasCoords(n, bounds); });

  // edges
  ctx.strokeStyle = "#3a4a5c";
  ctx.lineWidth = 2;
  state.edges.forEach(([a, b]) => {
    const pa = posById[a], pb = posById[b];
    if (!pa || !pb) return;
    ctx.beginPath();
    ctx.moveTo(pa.x, pa.y);
    ctx.lineTo(pb.x, pb.y);
    ctx.stroke();
  });

  // nodes
  state.nodes.forEach((n) => {
    const p = posById[n.id];
    ctx.beginPath();
    ctx.arc(p.x, p.y, NODE_RADIUS, 0, Math.PI * 2);
    ctx.fillStyle = n.active ? "#2ecc71" : "#7f8c8d";
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = "#0b1119";
    ctx.stroke();

    ctx.fillStyle = "#0b1119";
    ctx.font = "11px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(n.label, p.x, p.y);
  });

  latestState = state;
  latestState._posById = posById; // cache for click hit-testing
}

// ------------------------------------------------------------------
// Side panel updates
// ------------------------------------------------------------------
function updateSidePanel(state) {
  tickCountEl.textContent = state.tick;

  componentsListEl.innerHTML = "";
  state.components.forEach((comp, i) => {
    const li = document.createElement("li");
    const labels = comp.map((id) => {
      const n = state.nodes.find((x) => x.id === id);
      return n ? n.label : id;
    });
    li.textContent = `Group ${i + 1}: ${labels.join(", ")}`;
    componentsListEl.appendChild(li);
  });

  nodeTableBody.innerHTML = "";
  state.nodes.forEach((n) => {
    const tr = document.createElement("tr");
    const readingsStr = Object.entries(n.readings || {})
      .map(([k, v]) => `${k}=${v}`).join(", ") || "--";
    tr.innerHTML = `
      <td>${n.label}</td>
      <td class="${n.active ? 'status-up' : 'status-down'}">${n.active ? 'UP' : 'DOWN'}</td>
      <td>${readingsStr}</td>
    `;
    nodeTableBody.appendChild(tr);
  });

  // keep the inject dropdown in sync
  const currentSelection = injectNodeSelect.value;
  injectNodeSelect.innerHTML = "";
  state.nodes.forEach((n) => {
    const opt = document.createElement("option");
    opt.value = n.id;
    opt.textContent = n.label;
    injectNodeSelect.appendChild(opt);
  });
  if (currentSelection) injectNodeSelect.value = currentSelection;
}

// ------------------------------------------------------------------
// API calls
// ------------------------------------------------------------------
async function fetchState() {
  const res = await fetch("/api/state");
  const state = await res.json();
  draw(state);
  updateSidePanel(state);
}

async function toggleNode(nodeId) {
  const node = latestState.nodes.find((n) => n.id === nodeId);
  if (!node) return;
  const endpoint = node.active ? "disconnect" : "reconnect";
  const res = await fetch(`/api/${endpoint}/${nodeId}`, { method: "POST" });
  const state = await res.json();
  draw(state);
  updateSidePanel(state);
}

async function injectReading() {
  const nodeId = parseInt(injectNodeSelect.value, 10);
  const value = parseFloat(injectValueInput.value);
  if (Number.isNaN(nodeId) || Number.isNaN(value)) return;
  const res = await fetch(`/api/inject/${nodeId}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sensor: "reading", value }),
  });
  const state = await res.json();
  draw(state);
  updateSidePanel(state);
  injectValueInput.value = "";
}

// ------------------------------------------------------------------
// Interaction
// ------------------------------------------------------------------
canvas.addEventListener("click", (evt) => {
  if (!latestState) return;
  const rect = canvas.getBoundingClientRect();
  const clickX = evt.clientX - rect.left;
  const clickY = evt.clientY - rect.top;

  for (const n of latestState.nodes) {
    const p = latestState._posById[n.id];
    const dist = Math.hypot(clickX - p.x, clickY - p.y);
    if (dist <= NODE_RADIUS) {
      toggleNode(n.id);
      break;
    }
  }
});

injectBtn.addEventListener("click", injectReading);

// ------------------------------------------------------------------
// Poll every 2 seconds so the view stays live even if another
// teammate's script or API client changes state concurrently.
// ------------------------------------------------------------------
fetchState();
setInterval(fetchState, 2000);
