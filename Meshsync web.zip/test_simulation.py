import random
from simulation import MeshSimulation
import app as app_module


def test_inject_spreads_multihop():
    s = MeshSimulation()
    s.inject_reading(0, "water_level", 4.2)           # Base -> ... -> N4 -> N7
    for n in range(9):
        assert s.stores[n].latest_readings.get("water_level") == 4.2, f"node {n} missing reading"
    print("PASS reading injected at Base reaches all 9 nodes through relays")


def test_partition_buffer_and_heal():
    s = MeshSimulation()
    s.disconnect(2); s.disconnect(3)                   # cut the Base---N4/N7 chain
    s.inject_reading(0, "water_level", 5.0)
    s.inject_reading(7, "soil_moisture", 33.0)
    assert s.stores[4].latest_readings.get("water_level") is None     # cut off from Base side
    assert s.stores[1].latest_readings.get("soil_moisture") is None
    assert not s.convergence()["fully_converged"]
    s.reconnect(2); s.reconnect(3)
    c = s.convergence()
    assert c["converged"] and c["fully_converged"], c
    assert s.stores[4].latest_readings.get("water_level") == 5.0
    assert s.stores[0].latest_readings.get("soil_moisture") == 33.0
    print("PASS partition: both sides keep working, then fully converge after reconnect")


def test_dead_node_buffers_locally_then_syncs():
    s = MeshSimulation()
    s.disconnect(4)
    s.inject_reading(4, "water_level", 9.9)            # sensor works, radio is down
    assert s.stores[0].latest_readings.get("water_level") is None
    s.reconnect(4)
    assert s.stores[0].latest_readings.get("water_level") == 9.9
    print("PASS a node with a dead radio buffers its reading and delivers it after reconnect")


def test_status_tracked_in_crdt():
    s = MeshSimulation()
    s.disconnect(3)
    assert s.stores[0].to_dict()["node_status"].get(3) is False     # propagated to Base
    s.reconnect(3)
    assert s.stores[0].to_dict()["node_status"].get(3) is True
    print("PASS node up/down status replicated via LWW-Register")


def test_lamport_clocks_advance_on_receive():
    s = MeshSimulation()
    for _ in range(5):
        s.inject_reading(0, "water_level", 1.0)
    assert s.clocks[4].counter >= 5
    s.inject_reading(4, "water_level", 2.0)           # N4 must not use an older timestamp
    assert s.stores[0].latest_readings.get("water_level") == 2.0
    print("PASS Lamport clocks catch up, so a later write always wins")


def test_relay_counter_grows():
    s = MeshSimulation()
    s.inject_reading(0, "water_level", 1.0)
    s.sync()
    assert s.to_state()["nodes"][1]["relay_total"] > 0
    assert s.convergence()["fully_converged"]
    print("PASS relay G-Counter increments and still converges")


def test_connected_groups_consistent_after_every_action():
    s = MeshSimulation()
    s.disconnect(2); s.disconnect(3)
    s.inject_reading(0, "water_level", 5.0)
    s.inject_reading(7, "soil_moisture", 33.0)
    c = s.convergence()
    assert c["converged"], c                  # each connected group is internally consistent
    assert not c["fully_converged"], c        # but the two sides genuinely differ
    print("PASS connected groups stay consistent after every action; split sides differ until healed")


def test_many_random_scenarios_converge():
    s = MeshSimulation()
    for seed in range(200):
        r = s.run_random_scenario(seed=seed)
        assert r["fully_converged"], f"seed {seed} did not converge: {r}"
    print("PASS 200 random scenarios (random failures, writes, reconnect orders): all converge")


def test_api():
    c = app_module.app.test_client()
    assert c.post("/api/reset").status_code == 200
    st = c.get("/api/state").get_json()
    assert len(st["nodes"]) == 9 and st["convergence"]["fully_converged"]
    assert c.post("/api/inject/0", json={"sensor": "water_level", "value": 4.2}).status_code == 200
    assert c.post("/api/inject/0", json={"sensor": "x", "value": "abc"}).status_code == 400
    assert c.post("/api/inject/0", json={"sensor": "x", "value": True}).status_code == 400
    assert c.post("/api/inject/0", json={"sensor": "", "value": 1}).status_code == 400
    assert c.post("/api/inject/99", json={"sensor": "x", "value": 1}).status_code == 404
    assert c.post("/api/disconnect/99").status_code == 404
    assert c.post("/api/disconnect/2").status_code == 200
    assert c.get("/api/reachable/0/4").get_json()["reachable"] is False
    assert c.post("/api/reconnect/2").status_code == 200
    assert c.get("/api/reachable/0/4").get_json()["reachable"] is True
    assert c.get("/api/convergence").get_json()["fully_converged"]
    r = c.post("/api/scenario/random", json={"seed": 3}).get_json()
    assert r["report"]["fully_converged"] and "state" in r
    assert c.post("/api/scenario/random", json={"seed": "x"}).status_code == 400
    assert c.get("/").status_code == 200
    assert c.get("/api/log").status_code == 200
    print("PASS Flask API: endpoints, validation (400/404), reachability, scenario")


if __name__ == "__main__":
    test_inject_spreads_multihop()
    test_partition_buffer_and_heal()
    test_dead_node_buffers_locally_then_syncs()
    test_status_tracked_in_crdt()
    test_lamport_clocks_advance_on_receive()
    test_relay_counter_grows()
    test_connected_groups_consistent_after_every_action()
    test_many_random_scenarios_converge()
    test_api()
    print("\nALL INTEGRATION TESTS PASSED")
