class LamportClock:
    def __init__(self, node_id):
        self.node_id = node_id
        self.counter = 0

    def tick(self):
        self.counter += 1
        return self.counter

    def update(self, received_counter):
        self.counter = max(self.counter, received_counter) + 1
        return self.counter


def compare(ts_a, node_a, ts_b, node_b):
    """Total order over (timestamp, node_id): ties between equal Lamport
    timestamps are broken by node_id so every replica picks the same winner."""
    if (ts_a, node_a) < (ts_b, node_b):
        return -1
    if (ts_a, node_a) > (ts_b, node_b):
        return 1
    return 0
