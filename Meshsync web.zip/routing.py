import uuid


class Message:
    def __init__(self, origin_id, payload, ttl=10, message_id=None):
        self.message_id = message_id or str(uuid.uuid4())
        self.origin_id = origin_id
        self.payload = payload
        self.ttl = ttl

    def forwarded(self):
        """Copy with TTL reduced by one, for the next hop."""
        return Message(self.origin_id, self.payload, self.ttl - 1, self.message_id)


class FloodingRouter:
    """One per node: owns that node's seen-message cache and forwarding decision."""

    def __init__(self, node_id, max_seen_cache=500):
        self.node_id = node_id
        self._seen = set()
        self._order = []
        self._max = max_seen_cache
        self.relay_count = 0

    def mark_seen(self, message_id):
        self._seen.add(message_id)
        self._order.append(message_id)
        if len(self._order) > self._max:            # bounded memory (FIFO eviction)
            self._seen.discard(self._order.pop(0))

    def should_process(self, message):
        """True only the FIRST time this node sees message_id (dedup)."""
        if message.message_id in self._seen:
            return False
        self.mark_seen(message.message_id)
        return True

    def get_forward_targets(self, message, neighbors, received_from=None):
        if message.ttl <= 0:
            return []
        targets = [n for n in neighbors if n != received_from]
        if targets:
            self.relay_count += 1
        return targets


def make_routers(network):
    return {nid: FloodingRouter(nid) for nid in network.nodes}


def flood(network, stores, origin_id, payload, ttl=10, routers=None):
    """
    Flood `payload` from origin_id across the CURRENT topology (hop by hop).
    Disconnected nodes are skipped automatically because adjacency is
    recomputed from live node state. Returns (delivered_node_ids, routers).
    """
    if routers is None:
        routers = make_routers(network)
    if not network.nodes[origin_id].active:
        return [], routers                          # a dead node cannot transmit

    msg = Message(origin_id, payload, ttl=ttl)
    adjacency = network.compute_adjacency()

    delivered = [origin_id]
    routers[origin_id].mark_seen(msg.message_id)
    queue = [(origin_id, msg, None)]

    while queue:
        current, m, came_from = queue.pop(0)
        for nb in routers[current].get_forward_targets(m, adjacency.get(current, set()), came_from):
            fwd = m.forwarded()
            if routers[nb].should_process(fwd):
                stores[nb].merge(payload)
                delivered.append(nb)
                queue.append((nb, fwd, current))
    return delivered, routers


def sync_round(network, stores, routers=None, ttl=10):
    """
    Anti-entropy round: every ACTIVE node floods its own current state.
    Run after reconnections so nodes that were cut off catch up. Safe to
    repeat any number of times because merge is idempotent.
    """
    if routers is None:
        routers = make_routers(network)
    for nid, node in network.nodes.items():
        if node.active:
            flood(network, stores, nid, stores[nid], ttl=ttl, routers=routers)
    return routers


def check_convergence(network, stores):
    """For each connected component, are all member stores identical?
    Returns {'converged': bool, 'components': [...]}. (Nodes in different
    components legitimately differ until they are reconnected.)"""
    report, all_ok = [], True
    for comp in network.get_connected_components():
        ids = sorted(comp)
        ok = all(stores[ids[0]].equals(stores[i]) for i in ids[1:])
        all_ok &= ok
        report.append({"nodes": ids, "converged": ok})
    return {"converged": all_ok, "components": report}
