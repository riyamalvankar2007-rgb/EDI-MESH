import random
from mesh_engine import MeshNetwork
from crdt import NodeCRDTStore
from lamport_clock import LamportClock
from routing import flood, make_routers, sync_round, check_convergence


def build():
    net = MeshNetwork()
    for i in range(5):                      # chain 0-1-2-3-4, each hop 40 apart, range 55
        net.add_node(i, i * 40, 0, radio_range=55)
    net.add_node(5, 500, 500, radio_range=55)   # isolated node
    stores = {n: NodeCRDTStore(n) for n in net.nodes}
    clocks = {n: LamportClock(n) for n in net.nodes}
    return net, stores, clocks, make_routers(net)


def inject(stores, clocks, nid, sensor, value):
    stores[nid].record_reading(sensor, value, clocks[nid].tick())


def test_multihop_delivery():
    net, stores, clocks, routers = build()
    inject(stores, clocks, 0, "water", 4.2)
    delivered, _ = flood(net, stores, 0, stores[0], routers=routers)
    assert set(delivered) == {0, 1, 2, 3, 4}
    assert stores[4].latest_readings.get("water") == 4.2
    assert stores[5].latest_readings.get("water") is None
    print("PASS multi-hop delivery 0 -> 4 through 3 relays; isolated node untouched")


def test_dedup():
    net, stores, clocks, routers = build()
    inject(stores, clocks, 0, "water", 1.0)
    delivered, _ = flood(net, stores, 0, stores[0], routers=routers)
    assert len(delivered) == len(set(delivered))
    print("PASS dedup: each node processes the message exactly once")


def test_ttl():
    net, stores, clocks, routers = build()
    inject(stores, clocks, 0, "water", 1.0)
    delivered, _ = flood(net, stores, 0, stores[0], ttl=2, routers=routers)
    assert set(delivered) == {0, 1, 2}
    print("PASS TTL=2 stops the flood after 2 hops")


def test_dead_node_cannot_send():
    net, stores, clocks, routers = build()
    net.disconnect_node(0)
    inject(stores, clocks, 0, "water", 1.0)
    delivered, _ = flood(net, stores, 0, stores[0], routers=routers)
    assert delivered == []
    print("PASS a disconnected node cannot transmit")


def test_partition_then_heal():
    net, stores, clocks, routers = build()
    net.disconnect_node(2)                              # chain splits {0,1} | {3,4}
    inject(stores, clocks, 0, "water", 5.0)
    inject(stores, clocks, 4, "soil", 33.0)
    sync_round(net, stores, routers)
    assert stores[1].latest_readings.get("soil") is None
    assert stores[3].latest_readings.get("water") is None
    net.reconnect_node(2)
    sync_round(net, stores, routers)
    sync_round(net, stores, routers)
    for n in [1, 2, 3, 4]:
        assert stores[0].equals(stores[n]), f"node {n} diverged"
    assert stores[3].latest_readings.get("water") == 5.0
    assert stores[1].latest_readings.get("soil") == 33.0
    print("PASS partition -> independent writes -> heal -> all 5 nodes converge")


def test_random_reconnect_orders():
    for seed in range(100):
        rng = random.Random(seed)
        net, stores, clocks, routers = build()
        for d in (1, 2, 3):
            net.disconnect_node(d)
        inject(stores, clocks, 0, "water", rng.random())
        inject(stores, clocks, 4, "water", rng.random())     # conflicting writes, same key
        inject(stores, clocks, 4, "soil", rng.random())
        order = [1, 2, 3]
        rng.shuffle(order)
        for d in order:
            net.reconnect_node(d)
            sync_round(net, stores, routers)                 # sync after each reconnect
        sync_round(net, stores, routers)
        for n in [1, 2, 3, 4]:
            assert stores[0].equals(stores[n]), f"seed {seed}: node {n} diverged"
    print("PASS 100 random reconnect orders (with conflicting writes): always converge")


def test_merge_properties():
    rng = random.Random(7)
    def rand_store(nid):
        s = NodeCRDTStore(nid)
        for _ in range(5):
            s.record_reading(rng.choice("abc"), rng.randint(0, 9), rng.randint(1, 20))
        return s
    def merged(x, y):
        z = NodeCRDTStore(99); z.merge(x); z.merge(y); return z
    for _ in range(200):
        a, b, c = rand_store(1), rand_store(2), rand_store(3)
        assert merged(a, b).equals(merged(b, a))                       # commutative
        assert merged(merged(a, b), c).equals(merged(a, merged(b, c))) # associative
        assert merged(a, a).equals(merged(a, NodeCRDTStore(99)))       # idempotent
    print("PASS CRDT merge is commutative, associative, idempotent (200 random trials)")


if __name__ == "__main__":
    test_multihop_delivery()
    test_dedup()
    test_ttl()
    test_dead_node_cannot_send()
    test_partition_then_heal()
    test_random_reconnect_orders()
    test_merge_properties()
    print("\nALL TESTS PASSED")
