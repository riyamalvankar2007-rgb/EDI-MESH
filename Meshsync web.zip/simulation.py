
import random
from mesh_engine import MeshNetwork
from crdt import NodeCRDTStore
from lamport_clock import LamportClock
from routing import flood, make_routers, sync_round, check_convergence

# node_id, x, y, label  (node 0 is the base station)
DEFAULT_LAYOUT = [
    (0, 50, 50, "Base"),
    (1, 90, 70, "N1"),
    (2, 130, 90, "N2"),
    (3, 170, 110, "N3"),
    (4, 210, 130, "N4"),
    (5, 70, 10, "N5"),
    (6, 100, -5, "N6"),     # reachable only via N5
    (7, 245, 150, "N7"),    # reachable only via N4
    (8, 75, 55, "N8"),
]
DEFAULT_RANGE = 55.0
MAX_LOG = 200


class MeshSimulation:
    def __init__(self, layout=None, radio_range=DEFAULT_RANGE):
        self.layout = layout or DEFAULT_LAYOUT
        self.radio_range = radio_range
        self.reset()

    # ------------------------------------------------------------------ setup
    def reset(self):
        self.net = MeshNetwork()
        for nid, x, y, label in self.layout:
            self.net.add_node(nid, x, y, radio_range=self.radio_range, label=label)
        self.stores = {n: NodeCRDTStore(n) for n in self.net.nodes}
        self.clocks = {n: LamportClock(n) for n in self.net.nodes}
        self.routers = make_routers(self.net)
        self.log = []

    def _log(self, kind, text):
        self.log.append({"tick": self.net.tick_count, "kind": kind, "text": text})
        del self.log[:-MAX_LOG]

    def _label(self, nid):
        return self.net.nodes[nid].label

    def _check(self, nid):
        if nid not in self.net.nodes:
            raise KeyError(nid)

    # -------------------------------------------------------- clock handling
    @staticmethod
    def _max_ts(store):
        ts = [t[2] for t in store.history._items]
        ts += [r.ts for r in store.node_status.values()]
        return max(ts) if ts else 0

    def _catch_up_clocks(self):
        """A node that has merged newer timestamps must not issue older ones."""
        for nid, store in self.stores.items():
            m = self._max_ts(store)
            if m >= self.clocks[nid].counter:
                self.clocks[nid].update(m)

    def _count_relays(self, before):
        """Record, in each forwarding node's G-Counter, how many times it relayed."""
        for nid, router in self.routers.items():
            diff = router.relay_count - before[nid]
            if diff > 0:
                self.stores[nid].relay_counts.increment(nid, diff)

    def _flood_from(self, origin, count_relays=True):
        before = {n: r.relay_count for n, r in self.routers.items()}
        delivered, _ = flood(self.net, self.stores, origin, self.stores[origin],
                             routers=self.routers)
        if count_relays:
            self._count_relays(before)
        self._catch_up_clocks()
        return delivered

    def _settle(self):
        """Let connected nodes finish exchanging state after an action (relay
        counters etc. propagate), so each connected group is consistent."""
        sync_round(self.net, self.stores, self.routers)
        self._catch_up_clocks()

    # -------------------------------------------------------------- actions
    def inject_reading(self, node_id, sensor, value):
        self._check(node_id)
        self.net.tick()
        ts = self.clocks[node_id].tick()
        self.stores[node_id].record_reading(sensor, value, ts)
        delivered = self._flood_from(node_id)
        self._settle()
        others = [self._label(n) for n in delivered if n != node_id]
        if not self.net.nodes[node_id].active:
            self._log("inject", f"{self._label(node_id)} (radio DOWN) stored {sensor}={value} locally; will spread after reconnect")
        elif others:
            self._log("inject", f"{self._label(node_id)} {sensor}={value} -> reached {', '.join(others)}")
        else:
            self._log("inject", f"{self._label(node_id)} {sensor}={value} (no neighbours in range, stored locally)")
        return delivered

    def disconnect(self, node_id):
        self._check(node_id)
        node = self.net.nodes[node_id]
        if not node.active:
            return []
        neighbours = sorted(self.net.compute_adjacency()[node_id])   # who could hear it
        self.net.disconnect_node(node_id)
        self.net.tick()
        for nb in neighbours:                                         # they notice it vanish
            self.stores[nb].set_node_status(node_id, False, self.clocks[nb].tick())
        for nb in neighbours:
            self._flood_from(nb)
        self._settle()
        self._log("disconnect", f"{self._label(node_id)} went DOWN (detected by {', '.join(self._label(n) for n in neighbours) or 'nobody'})")
        return neighbours

    def reconnect(self, node_id):
        self._check(node_id)
        node = self.net.nodes[node_id]
        if node.active:
            return []
        self.net.reconnect_node(node_id)
        self.net.tick()
        self.stores[node_id].set_node_status(node_id, True, self.clocks[node_id].tick())
        self._log("reconnect", f"{self._label(node_id)} is back UP")
        return self.sync()

    def sync(self):
        """Anti-entropy: every active node floods its state. Safe to repeat."""
        sync_round(self.net, self.stores, self.routers)
        self._catch_up_clocks()
        self._log("sync", "sync round complete")
        return [n for n, node in self.net.nodes.items() if node.active]

    # ------------------------------------------------------------ reporting
    def convergence(self):
        per_component = check_convergence(self.net, self.stores)
        ids = sorted(self.stores)
        fully = all(self.stores[ids[0]].equals(self.stores[i]) for i in ids[1:])
        return {
            "converged": per_component["converged"],      # within each connected group
            "fully_converged": fully,                     # every node identical
            "components": [
                {"nodes": [self._label(n) for n in c["nodes"]], "converged": c["converged"]}
                for c in per_component["components"]
            ],
        }

    def reachable(self, a, b):
        self._check(a); self._check(b)
        return self.net.is_reachable(a, b)

    def to_state(self):
        adjacency = self.net.compute_adjacency()
        nodes = []
        for nid, node in self.net.nodes.items():
            d = self.stores[nid].to_dict()
            nodes.append({
                "id": nid, "label": node.label, "x": node.x, "y": node.y,
                "radio_range": node.radio_range, "active": node.active,
                "readings": d["latest_readings"],
                "event_count": d["event_count"],
                "relay_total": d["relay_total"],
                "known_status": {str(k): v for k, v in d["node_status"].items()},
                "clock": self.clocks[nid].counter,
            })
        edges = sorted({tuple(sorted((a, b))) for a, nbs in adjacency.items() for b in nbs})
        return {
            "tick": self.net.tick_count,
            "nodes": nodes,
            "edges": [list(e) for e in edges],
            "components": [sorted(c) for c in self.net.get_connected_components()],
            "convergence": self.convergence(),
            "log": self.log[-30:],
        }

    # ------------------------------------------------- automated test scenario
    def run_random_scenario(self, seed=None, n_down=3, n_readings=6, sensors=("water_level", "soil_moisture")):
        """
        Disconnect some nodes, inject readings at random nodes (including dead
        ones), reconnect in random order, sync, and report convergence.
        Used for the demo and for repeated-run convergence testing.
        """
        rng = random.Random(seed)
        self.reset()
        ids = list(self.net.nodes)
        down = rng.sample(ids, min(n_down, len(ids)))
        for d in down:
            self.disconnect(d)
        for _ in range(n_readings):
            self.inject_reading(rng.choice(ids), rng.choice(sensors), round(rng.uniform(0, 100), 1))
        order = down[:]
        rng.shuffle(order)
        for d in order:
            self.reconnect(d)
        self.sync()
        report = self.convergence()
        report.update({"seed": seed, "disconnected": [self._label(d) for d in down],
                       "reconnect_order": [self._label(d) for d in order]})
        return report
