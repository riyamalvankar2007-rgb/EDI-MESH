from lamport_clock import compare


class GSet:
    """Grow-only set; merge = union."""
    def __init__(self):
        self._items = set()

    def add(self, item):
        self._items.add(item)

    def merge(self, other):
        m = GSet()
        m._items = self._items | other._items
        return m

    def to_list(self):
        return sorted(self._items, key=lambda t: (t[2], t[3]))

    def __len__(self):
        return len(self._items)

    def __eq__(self, other):
        return isinstance(other, GSet) and self._items == other._items


class LWWMap:
    """key -> (value, lamport_ts, node_id); higher (ts, node_id) wins."""
    def __init__(self):
        self._entries = {}

    def set(self, key, value, ts, node_id):
        cur = self._entries.get(key)
        if cur is None or compare(ts, node_id, cur[1], cur[2]) > 0:
            self._entries[key] = (value, ts, node_id)

    def get(self, key):
        e = self._entries.get(key)
        return e[0] if e else None

    def merge(self, other):
        m = LWWMap()
        m._entries = dict(self._entries)
        for k, (v, ts, nid) in other._entries.items():
            m.set(k, v, ts, nid)
        return m

    def to_dict(self):
        return {k: v[0] for k, v in self._entries.items()}

    def __eq__(self, other):
        return isinstance(other, LWWMap) and self._entries == other._entries


class LWWRegister:
    """Single value that gets overwritten; higher (ts, node_id) wins."""
    def __init__(self, value=None, ts=0, node_id=None):
        self.value, self.ts, self.node_id = value, ts, node_id

    def set(self, value, ts, node_id):
        if compare(ts, node_id, self.ts, self.node_id) > 0:
            self.value, self.ts, self.node_id = value, ts, node_id

    def merge(self, other):
        m = LWWRegister(self.value, self.ts, self.node_id)
        m.set(other.value, other.ts, other.node_id)
        return m

    def __eq__(self, other):
        return isinstance(other, LWWRegister) and \
            (self.value, self.ts, self.node_id) == (other.value, other.ts, other.node_id)


class GCounter:
    """Each node increments only its own slot; merge = element-wise max."""
    def __init__(self):
        self._slots = {}

    def increment(self, node_id, amount=1):
        self._slots[node_id] = self._slots.get(node_id, 0) + amount

    def value(self):
        return sum(self._slots.values())

    def merge(self, other):
        m = GCounter()
        for nid in set(self._slots) | set(other._slots):
            m._slots[nid] = max(self._slots.get(nid, 0), other._slots.get(nid, 0))
        return m

    def __eq__(self, other):
        return isinstance(other, GCounter) and self._slots == other._slots


class NodeCRDTStore:
    """All four CRDTs bundled as one per-node store; this is what gets merged."""
    def __init__(self, node_id):
        self.node_id = node_id
        self.history = GSet()
        self.latest_readings = LWWMap()
        self.relay_counts = GCounter()
        self.node_status = {}          # target node_id -> LWWRegister

    def record_reading(self, sensor_id, value, ts):
        self.history.add((sensor_id, value, ts, self.node_id))
        self.latest_readings.set(sensor_id, value, ts, self.node_id)

    def record_relay(self):
        self.relay_counts.increment(self.node_id)

    def set_node_status(self, target_id, active, ts):
        reg = self.node_status.setdefault(target_id, LWWRegister())
        reg.set(active, ts, self.node_id)

    def merge(self, other):
        self.history = self.history.merge(other.history)
        self.latest_readings = self.latest_readings.merge(other.latest_readings)
        self.relay_counts = self.relay_counts.merge(other.relay_counts)
        for tid, reg in other.node_status.items():
            mine = self.node_status.get(tid)
            self.node_status[tid] = reg.merge(LWWRegister()) if mine is None else mine.merge(reg)

    def equals(self, other):
        return (self.history == other.history
                and self.latest_readings == other.latest_readings
                and self.relay_counts == other.relay_counts
                and self.node_status == other.node_status)

    def to_dict(self):
        return {
            "latest_readings": self.latest_readings.to_dict(),
            "event_count": len(self.history),
            "relay_total": self.relay_counts.value(),
            "node_status": {n: r.value for n, r in self.node_status.items()},
        }
