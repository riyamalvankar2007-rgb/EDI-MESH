"""
app.py -- Flask API for MeshSync.

A thin layer: every route validates input, takes a lock, and calls into
MeshSimulation (simulation.py). No routing or CRDT logic lives here.

Run:   python app.py        then open http://127.0.0.1:5000
"""
import math
import threading
from flask import Flask, jsonify, request, render_template
from simulation import MeshSimulation

app = Flask(__name__)
sim = MeshSimulation()
lock = threading.Lock()          # Flask's dev server is threaded; serialize state changes


def err(message, code):
    return jsonify({"error": message}), code


def node_or_404(node_id):
    if node_id not in sim.net.nodes:
        return err(f"unknown node {node_id}", 404)
    return None


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/state")
def get_state():
    with lock:
        return jsonify(sim.to_state())


@app.route("/api/convergence")
def get_convergence():
    with lock:
        return jsonify(sim.convergence())


@app.route("/api/log")
def get_log():
    with lock:
        return jsonify(sim.log)


@app.route("/api/disconnect/<int:node_id>", methods=["POST"])
def disconnect(node_id):
    with lock:
        bad = node_or_404(node_id)
        if bad:
            return bad
        sim.disconnect(node_id)
        return jsonify(sim.to_state())


@app.route("/api/reconnect/<int:node_id>", methods=["POST"])
def reconnect(node_id):
    with lock:
        bad = node_or_404(node_id)
        if bad:
            return bad
        sim.reconnect(node_id)
        return jsonify(sim.to_state())


@app.route("/api/inject/<int:node_id>", methods=["POST"])
def inject(node_id):
    """Body: {"sensor": "water_level", "value": 4.2}.
    Real ESP32/Arduino sensors can POST to this same endpoint."""
    payload = request.get_json(silent=True) or {}
    sensor = payload.get("sensor", "reading")
    value = payload.get("value")
    if not isinstance(sensor, str) or not sensor.strip():
        return err("'sensor' must be a non-empty string", 400)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        return err("'value' must be a finite number", 400)
    with lock:
        bad = node_or_404(node_id)
        if bad:
            return bad
        sim.inject_reading(node_id, sensor.strip(), value)
        return jsonify(sim.to_state())


@app.route("/api/sync", methods=["POST"])
def sync():
    with lock:
        sim.sync()
        return jsonify(sim.to_state())


@app.route("/api/reset", methods=["POST"])
def reset():
    with lock:
        sim.reset()
        return jsonify(sim.to_state())


@app.route("/api/scenario/random", methods=["POST"])
def scenario():
    """Body (optional): {"seed": 7}. Disconnects some nodes, injects readings,
    reconnects in random order, syncs, and reports convergence."""
    payload = request.get_json(silent=True) or {}
    seed = payload.get("seed")
    if seed is not None and (isinstance(seed, bool) or not isinstance(seed, int)):
        return err("'seed' must be an integer", 400)
    with lock:
        report = sim.run_random_scenario(seed=seed)
        return jsonify({"report": report, "state": sim.to_state()})


@app.route("/api/reachable/<int:a>/<int:b>")
def reachable(a, b):
    with lock:
        for n in (a, b):
            bad = node_or_404(n)
            if bad:
                return bad
        return jsonify({"reachable": sim.reachable(a, b)})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
