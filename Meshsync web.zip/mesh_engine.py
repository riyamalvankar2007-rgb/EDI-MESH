import math
import itertools


class Node:
    def __init__(self, node_id, x, y, radio_range=30.0, label=None):
        self.node_id = node_id
        self.x = x
        self.y = y
        self.radio_range = radio_range
        self.active = True
        self.label = label or str(node_id)

    def distance_to(self, other):
        return math.hypot(self.x - other.x, self.y - other.y)

    def disconnect(self):
        self.active = False

    def reconnect(self):
        self.active = True


class MeshNetwork:
    def __init__(self):
        self.nodes = {}
        self.tick_count = 0

    def add_node(self, node_id, x, y, radio_range=30.0, label=None):
        if node_id in self.nodes:
            raise ValueError(f"Node id {node_id} already exists")
        self.nodes[node_id] = Node(node_id, x, y, radio_range, label)
        return self.nodes[node_id]

    def disconnect_node(self, node_id):
        self.nodes[node_id].disconnect()

    def reconnect_node(self, node_id):
        self.nodes[node_id].reconnect()

    def compute_adjacency(self):
        adjacency = {nid: set() for nid in self.nodes}
        for a, b in itertools.combinations(self.nodes.values(), 2):
            if not a.active or not b.active:
                continue
            if a.distance_to(b) <= min(a.radio_range, b.radio_range):
                adjacency[a.node_id].add(b.node_id)
                adjacency[b.node_id].add(a.node_id)
        return adjacency

    def get_connected_components(self):
        adjacency = self.compute_adjacency()
        visited, components = set(), []
        for start in self.nodes:
            if start in visited:
                continue
            comp, queue = set(), [start]
            visited.add(start)
            while queue:
                cur = queue.pop(0)
                comp.add(cur)
                for nb in adjacency[cur]:
                    if nb not in visited:
                        visited.add(nb)
                        queue.append(nb)
            components.append(comp)
        return components

    def is_reachable(self, a, b):
        return any(a in c and b in c for c in self.get_connected_components())

    def tick(self):
        self.tick_count += 1
